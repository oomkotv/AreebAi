package com.areeb.ai.call

import android.telecom.Call
import android.telecom.CallScreeningService
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object CallState { var lastCaller by mutableStateOf<String?>(null) }

/**
 * v0.1: identifies the incoming number and lets the call ring normally.
 * Android does not let third-party apps speak into a live call or record its audio,
 * so "AI answers the caller" needs a different design (see README).
 */
class AreebCallScreeningService : CallScreeningService() {
    override fun onScreenCall(callDetails: Call.Details) {
        CallState.lastCaller = callDetails.handle?.schemeSpecificPart ?: "unknown"
        respondToCall(callDetails, CallResponse.Builder().build())
    }
}
