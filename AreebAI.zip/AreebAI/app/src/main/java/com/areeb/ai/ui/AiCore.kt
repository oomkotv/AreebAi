package com.areeb.ai.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.min
import kotlin.math.sin

@Composable
private fun rememberPhase(): Float {
    val t by rememberInfiniteTransition(label = "phase").animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart),
        label = "t"
    )
    return t
}

@Composable
fun AiCore(level: Float, modifier: Modifier = Modifier) {
    val t = rememberPhase()
    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height / 2)
        val base = min(size.width, size.height) / 2 * 0.45f
        val r = base * (1f + 0.05f * sin(t * 2) + level * 0.18f)
        drawCircle(
            Brush.radialGradient(listOf(ElectricBlue.copy(alpha = 0.45f), Color.Transparent), c, r * 1.9f),
            radius = r * 1.9f, center = c
        )
        drawCircle(ElectricBlue.copy(alpha = 0.9f), r, c, style = Stroke(4f))
        drawCircle(ElectricBlue.copy(alpha = 0.4f), r * 1.25f, c, style = Stroke(2f))
        drawCircle(ElectricBlue.copy(alpha = 0.2f), r * 1.5f, c, style = Stroke(1.5f))
        drawArc(
            ElectricBlue, startAngle = t * 57.3f, sweepAngle = 110f, useCenter = false,
            topLeft = Offset(c.x - r * 1.12f, c.y - r * 1.12f), size = Size(r * 2.24f, r * 2.24f),
            style = Stroke(6f, cap = StrokeCap.Round)
        )
        drawCircle(Color.White.copy(alpha = 0.85f), r * 0.18f, c)
    }
}

@Composable
fun Waveform(level: Float, active: Boolean, modifier: Modifier = Modifier) {
    val t = rememberPhase()
    Canvas(modifier) {
        val n = 28
        val gap = size.width / n
        val amp = if (active) 0.25f + level * 0.75f else 0.08f
        for (i in 0 until n) {
            val h = size.height * amp * (0.35f + 0.65f * (sin(t * 3 + i * 0.55f) * 0.5f + 0.5f))
            val x = gap * i + gap / 2
            drawLine(
                ElectricBlue, Offset(x, size.height / 2 - h / 2), Offset(x, size.height / 2 + h / 2),
                strokeWidth = gap * 0.5f, cap = StrokeCap.Round
            )
        }
    }
}
