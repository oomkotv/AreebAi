package com.areeb.ai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ElectricBlue = Color(0xFF00B4FF)

@Composable
fun AreebTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = ElectricBlue,
            background = Color.Black,
            surface = Color(0xFF0A0F14),
            onSurface = Color.White,
            onBackground = Color.White
        ),
        content = content
    )
}
