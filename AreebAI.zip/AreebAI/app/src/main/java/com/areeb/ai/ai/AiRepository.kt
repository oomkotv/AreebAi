package com.areeb.ai.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Talks to YOUR backend (see /backend). API keys never live inside the APK. */
class AiRepository {
    suspend fun chat(
        baseUrl: String,
        token: String,
        model: String, // "claude" | "gemini" | "openai"
        history: List<Pair<String, String>>
    ): String = withContext(Dispatchers.IO) {
        val conn = (URL(baseUrl.trimEnd('/') + "/chat").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 60_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            if (token.isNotEmpty()) setRequestProperty("x-app-token", token)
        }
        val msgs = JSONArray()
        history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject().put("model", model).put("messages", msgs).toString()
        conn.outputStream.use { it.write(body.toByteArray()) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw IOException("HTTP $code: ${text.take(200)}")
        JSONObject(text).getString("text")
    }
}
