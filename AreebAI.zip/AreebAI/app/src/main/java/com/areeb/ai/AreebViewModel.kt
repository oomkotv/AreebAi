package com.areeb.ai

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.areeb.ai.ai.AiRepository
import com.areeb.ai.commands.CommandRouter
import com.areeb.ai.device.DeviceController
import com.areeb.ai.voice.VoiceManager
import kotlinx.coroutines.launch

data class ChatMsg(val role: String, val text: String)

class AreebViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val prefs = ctx.getSharedPreferences("areeb", Context.MODE_PRIVATE)
    private val device = DeviceController(ctx)
    private val ai = AiRepository()

    val messages = mutableStateListOf<ChatMsg>()
    var model by mutableStateOf("claude")
    var lang by mutableStateOf("en-US")
    var listening by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var level by mutableFloatStateOf(0f)
    var backendUrl by mutableStateOf(prefs.getString("backend", BuildConfig.BACKEND_URL) ?: BuildConfig.BACKEND_URL)
    var appToken by mutableStateOf(prefs.getString("token", "") ?: "")

    val voice = VoiceManager(
        ctx,
        onResult = { send(it) },
        onLevel = { level = it },
        onState = { listening = it },
        onError = { notify(it) }
    )

    fun saveSettings(url: String, token: String) {
        backendUrl = url.trim(); appToken = token.trim()
        prefs.edit().putString("backend", backendUrl).putString("token", appToken).apply()
    }

    fun setLanguage(tag: String) { lang = tag; voice.langTag = tag }

    fun notify(text: String) { messages.add(ChatMsg("system", text)) }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        voice.stopSpeaking()
        messages.add(ChatMsg("user", t))

        val cmdReply = CommandRouter.route(t, ctx, device)
        if (cmdReply != null) { reply(cmdReply); return }

        viewModelScope.launch {
            busy = true
            try {
                val history = messages
                    .filter { it.role == "user" || it.role == "assistant" }
                    .takeLast(12)
                    .map { it.role to it.text }
                    .dropWhile { it.first != "user" }
                reply(ai.chat(backendUrl, appToken, model, history))
            } catch (e: Exception) {
                notify("AI error: ${e.message}")
            } finally {
                busy = false
            }
        }
    }

    private fun reply(text: String) {
        messages.add(ChatMsg("assistant", text))
        voice.speak(text)
    }

    override fun onCleared() { voice.release() }
}
