package com.areeb.ai.ui

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.areeb.ai.AreebViewModel
import com.areeb.ai.automation.AreebAccessibilityService
import com.areeb.ai.call.CallState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Dashboard(vm: AreebViewModel) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var urlField by remember { mutableStateOf(vm.backendUrl) }
    var tokenField by remember { mutableStateOf(vm.appToken) }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.voice.startListening() else vm.notify("Microphone permission denied.")
    }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {}
    val listState = rememberLazyListState()
    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.size - 1)
    }

    fun onMic() {
        if (vm.listening) { vm.voice.stopListening(); return }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            vm.voice.startListening()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    Column(
        Modifier.fillMaxSize().background(Color.Black).systemBarsPadding().imePadding().padding(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("AREEB AI", color = ElectricBlue, fontSize = 22.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { showSettings = !showSettings }) { Text("Settings") }
        }

        if (showSettings) {
            OutlinedTextField(urlField, { urlField = it }, label = { Text("Backend URL") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(tokenField, { tokenField = it }, label = { Text("App token (optional)") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                listOf("English" to "en-US", "اردو" to "ur-PK", "Roman Urdu" to "en-IN").forEach { (label, tag) ->
                    FilterChip(vm.lang == tag, { vm.setLanguage(tag) }, { Text(label) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.saveSettings(urlField, tokenField) }) { Text("Save") }
                OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                    Text(if (AreebAccessibilityService.isEnabled) "Accessibility: ON" else "Enable Accessibility")
                }
            }
            OutlinedButton(onClick = {
                val rm = ctx.getSystemService(RoleManager::class.java)
                if (rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING))
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
            }) { Text("Enable call screening") }
            CallState.lastCaller?.let { Text("Last incoming call: $it", color = Color.Gray, fontSize = 12.sp) }
        }

        AiCore(vm.level, Modifier.fillMaxWidth().weight(1f))
        Waveform(vm.level, vm.listening, Modifier.fillMaxWidth().height(36.dp))

        LazyColumn(state = listState, modifier = Modifier.fillMaxWidth().weight(1f).padding(vertical = 8.dp)) {
            items(vm.messages) { m ->
                val color = when (m.role) { "user" -> Color.White; "assistant" -> ElectricBlue; else -> Color.Gray }
                val who = when (m.role) { "user" -> "You"; "assistant" -> "Areeb"; else -> "•" }
                Text("$who: ${m.text}", color = color, modifier = Modifier.padding(vertical = 3.dp))
            }
            if (vm.busy) item { Text("Areeb is thinking…", color = Color.Gray) }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("claude" to "Claude", "gemini" to "Gemini", "openai" to "OpenAI").forEach { (id, label) ->
                FilterChip(vm.model == id, { vm.model = id }, { Text(label) })
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
            OutlinedTextField(
                input, { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Type a command or question") }, singleLine = true
            )
            Spacer(Modifier.width(6.dp))
            Button(onClick = { vm.send(input); input = "" }, shape = RoundedCornerShape(12.dp)) { Text("Send") }
            Spacer(Modifier.width(6.dp))
            Button(
                onClick = { onMic() }, shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (vm.listening) Color(0xFFFF3B30) else ElectricBlue
                )
            ) { Text(if (vm.listening) "Stop" else "Mic") }
        }
    }
}
