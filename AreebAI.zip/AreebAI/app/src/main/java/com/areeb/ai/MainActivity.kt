package com.areeb.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.areeb.ai.ui.AreebTheme
import com.areeb.ai.ui.Dashboard

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AreebTheme {
                val vm: AreebViewModel = viewModel()
                Dashboard(vm)
            }
        }
    }
}
