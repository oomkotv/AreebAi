package com.areeb.ai.commands

import android.content.Context
import android.provider.Settings
import com.areeb.ai.automation.AreebAccessibilityService
import com.areeb.ai.device.DeviceController

/**
 * Maps English / Roman Urdu phrases to real device actions.
 * Returns the reply text, or null if the text is not a command (-> goes to the AI model).
 */
object CommandRouter {

    private val wake = Regex("^(hey|hi|ok)?\\s*areeb[,!]?\\s*", RegexOption.IGNORE_CASE)
    private const val NEED_A11Y = "Please enable AREEB AI in Accessibility settings first."

    fun route(raw: String, ctx: Context, dev: DeviceController): String? {
        val cleaned = raw.trim().replace(wake, "").trim()
        val t = cleaned.lowercase()
        val a11y = AreebAccessibilityService.instance

        // YouTube
        if (t.contains("youtube")) {
            val q = Regex("(?:search for|search karo|search kro|search|dhoondo|talash karo)\\s+(.+)")
                .find(t)?.groupValues?.get(1)?.removeSuffix(" on youtube")?.trim()
            return if (q != null) {
                if (dev.youtubeSearch(q)) "Searching YouTube for $q." else "Could not open YouTube."
            } else {
                if (dev.openApp("youtube")) "Opening YouTube." else "YouTube is not installed."
            }
        }

        // Device
        if (Regex("(flashlight|torch).*\\bon\\b|turn on (the )?(flashlight|torch)|torch jalao").containsMatchIn(t))
            return if (dev.torch(true)) "Flashlight on." else "Flashlight is not available."
        if (Regex("(flashlight|torch).*\\boff\\b|turn off (the )?(flashlight|torch)|torch band").containsMatchIn(t))
            return if (dev.torch(false)) "Flashlight off." else "Flashlight is not available."
        if (Regex("increase volume|volume up|awaz barhao|volume barhao").containsMatchIn(t)) { dev.volume(true); return "Volume up." }
        if (Regex("decrease volume|volume down|awaz kam|volume kam").containsMatchIn(t)) { dev.volume(false); return "Volume down." }
        if (t.contains("battery")) return "Battery is at ${dev.batteryPercent()} percent."
        if (t.contains("wifi settings") || t.contains("wi-fi settings")) { dev.openSettings(Settings.ACTION_WIFI_SETTINGS); return "Opening Wi-Fi settings." }
        if (t.contains("bluetooth settings")) { dev.openSettings(Settings.ACTION_BLUETOOTH_SETTINGS); return "Opening Bluetooth settings." }
        if (t == "open settings" || t == "settings kholo") { dev.openSettings(); return "Opening settings." }

        // Accessibility automation
        if (t == "go back" || t == "back" || t == "peeche jao") {
            if (a11y == null) return NEED_A11Y
            a11y.back(); return "Going back."
        }
        if (t == "go home" || t == "home" || t == "home screen") {
            if (a11y == null) return NEED_A11Y
            a11y.home(); return "Going home."
        }
        if (t.startsWith("scroll down")) {
            if (a11y == null) return NEED_A11Y
            return if (a11y.scroll(true)) "Scrolling down." else "Nothing to scroll."
        }
        if (t.startsWith("scroll up")) {
            if (a11y == null) return NEED_A11Y
            return if (a11y.scroll(false)) "Scrolling up." else "Nothing to scroll."
        }
        if (t == "read screen" || t == "read the screen") {
            if (a11y == null) return NEED_A11Y
            return a11y.readScreen().ifBlank { "I could not read any text." }
        }
        Regex("^(?:tap|click)\\s+(.+)").find(t)?.let { m ->
            if (a11y == null) return NEED_A11Y
            val label = m.groupValues[1]
            return if (a11y.clickText(label)) "Tapped $label." else "I could not find $label."
        }
        Regex("^type\\s+(.+)", RegexOption.IGNORE_CASE).find(cleaned)?.let { m ->
            if (a11y == null) return NEED_A11Y
            return if (a11y.typeText(m.groupValues[1])) "Typed." else "No editable field found. I never type into password fields."
        }

        // Open app / web search
        Regex("^(?:open|launch|chalao)\\s+(.+)").find(t)?.let { m ->
            val n = m.groupValues[1]
            return if (dev.openApp(n)) "Opening $n." else "I could not find an app called $n."
        }
        Regex("^(.+)\\s+(?:kholo|khol do)$").find(t)?.let { m ->
            val n = m.groupValues[1]
            return if (dev.openApp(n)) "Opening $n." else "I could not find an app called $n."
        }
        Regex("^search (?:for )?(.+)").find(t)?.let { m ->
            dev.webSearch(m.groupValues[1]); return "Searching for ${m.groupValues[1]}."
        }
        return null
    }
}
