package com.areeb.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Push-to-talk STT + TTS. Call from the main thread. Wake word is NOT in v0.1. */
class VoiceManager(
    private val ctx: Context,
    private val onResult: (String) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onState: (Boolean) -> Unit,
    private val onError: (String) -> Unit
) {
    var langTag: String = "en-US"
    private var recognizer: SpeechRecognizer? = null
    private val tts: TextToSpeech = TextToSpeech(ctx) { }

    fun speak(text: String) {
        tts.language = Locale.forLanguageTag(langTag)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "areeb")
    }

    /** Interrupt a spoken response. */
    fun stopSpeaking() { tts.stop() }

    fun startListening() {
        stopSpeaking()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onError("Speech recognition is not available on this device.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) { onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f)) }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { onState(false); onLevel(0f) }
                override fun onError(error: Int) {
                    onState(false); onLevel(0f)
                    if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                        this@VoiceManager.onError("Speech error code $error")
                }
                override fun onResults(results: Bundle?) {
                    onState(false); onLevel(0f)
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!text.isNullOrBlank()) onResult(text)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
        recognizer?.startListening(intent)
        onState(true)
    }

    fun stopListening() { recognizer?.stopListening(); onState(false) }

    fun release() {
        recognizer?.destroy()
        tts.stop(); tts.shutdown()
    }
}
