// Minimal proxy so API keys stay off the phone. Node 18+, no dependencies.
// Run:  ANTHROPIC_API_KEY=... OPENAI_API_KEY=... GEMINI_API_KEY=... node server.js
const http = require('http');
const PORT = process.env.PORT || 8787;
const SYSTEM = "You are AREEB AI, a professional, friendly personal assistant. Reply in the user's language (English, Urdu, or Roman Urdu). Keep answers concise because they are spoken aloud.";

async function claude(messages) {
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: process.env.CLAUDE_MODEL || 'claude-sonnet-4-6', max_tokens: 1024, system: SYSTEM, messages })
  });
  const j = await r.json(); if (!r.ok) throw new Error(JSON.stringify(j));
  return j.content.map(c => c.text || '').join('');
}
async function openai(messages) {
  const r = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + process.env.OPENAI_API_KEY },
    body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', messages: [{ role: 'system', content: SYSTEM }, ...messages] })
  });
  const j = await r.json(); if (!r.ok) throw new Error(JSON.stringify(j));
  return j.choices[0].message.content;
}
async function gemini(messages) {
  const m = process.env.GEMINI_MODEL || 'gemini-2.0-flash';
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-goog-api-key': process.env.GEMINI_API_KEY },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: SYSTEM }] },
      contents: messages.map(x => ({ role: x.role === 'assistant' ? 'model' : 'user', parts: [{ text: x.content }] }))
    })
  });
  const j = await r.json(); if (!r.ok) throw new Error(JSON.stringify(j));
  return j.candidates[0].content.parts.map(p => p.text || '').join('');
}
const providers = { claude, openai, gemini };

http.createServer((req, res) => {
  const send = (code, obj) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); };
  if (req.method !== 'POST' || req.url !== '/chat') return send(404, { error: 'not found' });
  if (process.env.APP_TOKEN && req.headers['x-app-token'] !== process.env.APP_TOKEN) return send(401, { error: 'bad token' });
  let body = '';
  req.on('data', c => { body += c; if (body.length > 1e6) req.destroy(); });
  req.on('end', async () => {
    try {
      const { model, messages } = JSON.parse(body);
      const fn = providers[model];
      if (!fn) return send(400, { error: 'unknown model' });
      send(200, { text: await fn(messages) });
    } catch (e) { send(500, { error: String(e.message || e) }); }
  });
}).listen(PORT, () => console.log('AREEB backend on :' + PORT));
