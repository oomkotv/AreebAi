# AREEB AI  v0.1 (untested skeleton)

NOT compiled or run by the author of this zip. Expect to fix a few compile errors on first build.

## Implemented (real code, untested)
- Compose dashboard: animated AI core, waveform, chat, model selector (Claude/Gemini/OpenAI), settings
- Push-to-talk STT (SpeechRecognizer) + TTS; sending a message or tapping Mic interrupts speech; EN / Urdu / Roman Urdu locale toggle
- Command router (English + Roman Urdu): open app, YouTube open/search, flashlight, volume, battery, Wi-Fi/Bluetooth/settings, back/home/scroll/tap/type/read screen
- AccessibilityService (never types into password fields)
- CallScreeningService: shows incoming number, lets the call ring normally
- Node backend proxy for Claude/Gemini/OpenAI

## NOT implemented yet
Wake word "Hey Areeb", persistent memory/history, reminders/tasks, file management, coding workspace UI,
YouTube Studio flows, AI auto-answering calls (Android blocks third-party apps from call audio).

## Run backend
cd backend
ANTHROPIC_API_KEY=... OPENAI_API_KEY=... GEMINI_API_KEY=... APP_TOKEN=secret node server.js
In the app: Settings -> Backend URL = http://<pc-or-phone-ip>:8787 (use HTTPS in production)

## Build APK
A (recommended): push folder to GitHub -> Actions -> "Build APK" -> download areeb-debug-apk.
B: Android Studio -> Open -> Run.
C: Termux (fragile): needs JDK 17, Gradle 8.7, Android SDK, and an aarch64 aapt2
   (set android.aapt2FromMavenOverride=/path/to/aapt2 in gradle.properties).

## First run
1. Install APK, open app. 2. Settings -> Enable Accessibility -> turn on AREEB AI.
3. (optional) Settings -> Enable call screening. 4. Tap Mic and say: "open YouTube and search for AI tutorials".
